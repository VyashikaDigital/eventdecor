/* Book page: availability calendar + booking request */
let cal=new Date(),sel="";
function calH(){const y=cal.getFullYear(),m=cal.getMonth(),f=new Date(y,m,1).getDay(),n=new Date(y,m+1,0).getDate(),td=today();let c="";for(let i=0;i<f;i++)c+="<span></span>";
for(let d=1;d<=n;d++){const k=`${y}-${String(m+1).padStart(2,"0")}-${String(d).padStart(2,"0")}`,b=st.busy[k],cl=k<td?"pa":b?(b.status==="booked"?"bk":"pe"):k===sel?"se":"";c+=`<button type="button" class="dy ${cl}" data-d="${k}">${d}</button>`}
return`<div class="ch"><button type="button" class="ib" data-m="-1">‹</button><b>${cal.toLocaleString("en",{month:"long",year:"numeric"})}</b><button type="button" class="ib" data-m="1">›</button></div><div class="cg">${"SMTWTFS".split("").map(x=>`<b>${x}</b>`).join("")}${c}</div><div class="lg"><span style="--c:#bbb">Available</span><span style="--c:#f4c95d">Pending</span><span style="--c:#c2406f">Booked</span><span style="--c:#2e9d62">Aapki date${sel?": "+sel:""}</span></div>`}
const draw=()=>$("#cal").innerHTML=calH();draw();
$("#t").innerHTML=T.map(t=>`<option>${t}</option>`).join("");
$("#cal").addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;
if(b.dataset.m){cal=new Date(cal.getFullYear(),cal.getMonth()+ +b.dataset.m,1);draw()}
if(b.dataset.d&&!b.classList.contains("pa")&&!st.busy[b.dataset.d]){sel=b.dataset.d;draw()}});
$("#f").addEventListener("submit",e=>{e.preventDefault();const v=i=>$("#"+i).value,er=$("#er");
if(!sel)return er.textContent="Pehle calendar se date chunein";
if(v("n").trim().length<2)return er.textContent="Naam likhein";
if(!/^[6-9]\d{9}$/.test(v("p").trim()))return er.textContent="Sahi 10-digit number likhein";
if(st.busy[sel])return er.textContent="Ye date ab available nahi hai";
const id=rid(),d={name:v("n").trim(),phone:v("p").trim(),type:v("t"),guests:v("g"),venue:v("v"),msg:v("m"),date:sel,status:"pending",at:Date.now()};
put("busy",sel,{id,type:d.type,status:"pending"});put("bookings",id,d);put("mine",id,{date:sel,type:d.type,name:d.name});
location.href="my-bookings.html"});
