/* Contact page: social links (admin Settings se control hote hain) */
const s=S(),l=(u,i,n)=>u?`<a class="out" href="${esc(u)}" target="_blank" rel="noopener" title="${n}">${i}</a>`:"";
$("#soc").innerHTML=l("https://wa.me/"+s.wa,"💬","WhatsApp")+l(s.ig,"📸","Instagram")+l(s.fb,"👍","Facebook")+l(s.yt,"▶️","YouTube");
