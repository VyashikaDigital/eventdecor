/* Shared layout: header, footer, theme, menu, WhatsApp button, 3D tilt */
(function(){
const s=S(),page=document.body.dataset.page;
document.documentElement.style.setProperty("--gold",s.color);
try{const t=localStorage.getItem("th");if(t)document.documentElement.dataset.theme=t}catch(e){}
const NAV=[["index.html","Home","home"],["services.html","Services","services"],["gallery.html","Gallery","gallery"],["book.html","Book","book"],["contact.html","Contact","contact"],["my-bookings.html","My Bookings","my"],["admin.html","⚙ Admin","admin"]];
$("#nav-root").innerHTML=`<nav><div class="wrap"><a href="index.html" class="logo out" style="text-decoration:none"><b class="gold">✦ ${esc(s.name)}</b></a><div class="links" id="lk">${NAV.map(([h,l,k])=>`<a href="${h}" class="${page===k?"on":""}">${l}</a>`).join("")}</div><div style="display:flex;gap:8px"><button class="ib" id="th" aria-label="Theme">🌙</button><button class="ib" id="mb" aria-label="Menu">☰</button></div></div></nav>`;
$("#foot-root").innerHTML=`<footer><div class="wrap"><b class="gold" style="font:700 1.3rem 'Playfair Display',serif">✦ ${esc(s.name)}</b><br>© 2026 All rights reserved<br><a href="contact.html#terms">Terms &amp; Conditions</a>·<a href="contact.html#terms">Refund Policy</a>·<a href="contact.html#terms">Privacy Policy</a></div></footer><a class="wa" href="https://wa.me/${esc(s.wa)}" target="_blank" rel="noopener" aria-label="WhatsApp">💬</a>`;
document.title=document.title.split("|")[0].trim()+" | "+s.name;
const ti=()=>$("#th").textContent=document.documentElement.dataset.theme==="dark"?"☀️":"🌙";ti();
$("#th").onclick=()=>{const r=document.documentElement,v=r.dataset.theme==="dark"?"light":"dark";r.dataset.theme=v;ti();try{localStorage.setItem("th",v)}catch(e){}};
$("#mb").onclick=()=>$("#lk").classList.toggle("open");
if($("#svc"))$("#svc").innerHTML=svc();
if(matchMedia("(hover:hover)").matches)$$(".tilt").forEach(c=>{c.onmousemove=e=>{const b=c.getBoundingClientRect(),x=(e.clientX-b.left)/b.width-.5,y=(e.clientY-b.top)/b.height-.5;c.style.transform=`perspective(800px) rotateY(${x*14}deg) rotateX(${-y*14}deg)`};c.onmouseleave=()=>c.style.transform=""});
})();
