/* Customer panel: apni bookings ka status, quote aur payment */
function draw(){const rows=Object.entries(st.mine).sort((a,b)=>a[1].date<b[1].date?-1:1);
$("#list").innerHTML=rows.length?rows.map(([id,b])=>{const bz=st.busy[b.date],ok=bz&&bz.id===id,s=ok?bz.status:"declined",q=st.quotes[id]||{},pc=q.quote?Math.min(100,(q.paid||0)/q.quote*100):0;
return`<div class="item out"><div class="r"><b>${esc(b.type)} · ${esc(b.date)}</b><span class="pill" style="--c:${s==="booked"?"#2e9d62":s==="pending"?"#d89b00":"#c2406f"}">${s==="booked"?"Confirmed":s==="pending"?"Pending":"Not available"}</span></div><div style="font-size:.85rem;color:var(--muted)">${esc(b.name)} · ID ${id}</div>${q.quote?`<div class="r" style="margin-top:10px"><span>Quote: <b>${inr(q.quote)}</b></span><span>Paid: <b>${inr(q.paid)}</b></span><span>Baaki: <b>${inr(q.quote-(q.paid||0))}</b></span></div><div class="bar in" style="margin-top:8px"><i style="width:${pc}%"></i></div>`:`<div class="note" style="text-align:left">Quote owner ki taraf se jald milega.</div>`}${s==="pending"?`<button class="btn s d" data-id="${id}">Cancel Request</button>`:""}</div>`}).join(""):`<div class="box out" style="text-align:center">Abhi koi booking nahi.<br><a class="btn p" href="book.html">Book Karein</a></div>`}
$("#list").addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;const id=b.dataset.id,m=st.mine[id];
if(m&&st.busy[m.date]&&st.busy[m.date].id===id)del("busy",m.date);
if(st.bookings[id])put("bookings",id,{...st.bookings[id],status:"cancelled"});draw()});
draw();
