/* Data layer: sab data yahin se read/write hota hai.
   Abhi localStorage use ho raha hai. Asli backend lagane par sirf put()/del() aur load ko API calls se badalna hoga. */
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const inr=n=>"₹"+Math.round(+n||0).toLocaleString("en-IN");
const COLS=["busy","quotes","settings","bookings","expenses","staff","mine"];
const DS={name:"Royal Events & Decor",wa:"910000000000",ig:"",fb:"",yt:"",color:"#b8892b",pin:"1234"};
const st={};COLS.forEach(c=>st[c]={});
try{const x=JSON.parse(localStorage.getItem("rd2")||"null");if(x)COLS.forEach(c=>st[c]=x[c]||{})}catch(e){}
const S=()=>({...DS,...(st.settings.main||{})});
function save(){try{localStorage.setItem("rd2",JSON.stringify(st))}catch(e){}}
function put(c,id,o){st[c][id]=o;save()}
function del(c,id){delete st[c][id];save()}
const rid=()=>"b"+Date.now().toString(36)+Math.random().toString(36).slice(2,6);
const today=()=>new Date().toISOString().slice(0,10);
function toast(m){const t=document.createElement("div");t.className="toast";t.textContent=m;document.body.append(t);setTimeout(()=>t.remove(),2400)}
const hd=(a,b,p)=>`<div class="head"><h2>${a} <span class="gold">${b}</span></h2>${p?`<p>${p}</p>`:""}</div>`;
const T=["Wedding","Birthday","Engagement","Corporate"],IC=["💍","🎂","💐","🏢"],BASE=[30000,12000,20000,25000],FROM=["₹30,000","₹12,000","₹20,000","₹25,000"];
const DESC=["Mandap, stage, floral &amp; lighting","Theme balloons, backdrops &amp; dessert tables","Ring ceremony &amp; sangeet setups","Launches, conferences &amp; annual days"];
const TL=["Royal Stage","Golden Mandap","Fairytale Theme","Floral Romance","Sunset Party","Gala Night"],TC=["Wedding","Wedding","Birthday","Engagement","Birthday","Corporate"];
const svc=()=>T.map((t,i)=>`<div class="card out tilt"><div class="ic in">${IC[i]}</div><h3>${t}</h3><p>${DESC[i]}</p><p class="price">Starting ${FROM[i]}</p></div>`).join("");
