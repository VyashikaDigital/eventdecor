/* Services page: instant estimate calculator */
$("#et").innerHTML=T.map((t,i)=>`<option value="${BASE[i]}">${t}</option>`).join("");
function est(){const g=+$("#gs").value;$("#gv").textContent=g;const lo=(+$("#et").value+g*180)*(+$("#ds").value),f=n=>inr(Math.round(n/1000)*1000);$("#ev").textContent=f(lo)+" – "+f(lo*1.25)}
["et","ds","gs"].forEach(i=>$("#"+i).oninput=est);est();
