/* Gallery page: filter + lightbox */
const gal=f=>TL.map((l,i)=>(f==="All"||TC[i]===f)?`<div class="tile out" data-lb="${i}"><i class="t${i}"><span><small>${TC[i]}</small>${l}</span></i></div>`:"").join("");
$("#tabs").innerHTML=["All",...T].map((t,i)=>`<button class="btn s ${i?"":"on"}" data-f="${t}">${t}</button>`).join("");
$("#gl").innerHTML=gal("All");
document.addEventListener("click",e=>{const t=e.target.closest("button,.tile");if(!t)return;
if(t.dataset.lb!==undefined){const d=$("#lb div");d.className="t"+t.dataset.lb;d.innerHTML=`<span>${TL[t.dataset.lb]}</span>`;$("#lb").classList.add("on")}
if(t.dataset.f){$$("#tabs button").forEach(x=>x.classList.toggle("on",x===t));$("#gl").innerHTML=gal(t.dataset.f)}});
$("#lb").onclick=()=>$("#lb").classList.remove("on");
