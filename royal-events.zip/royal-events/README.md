# Royal Events & Decor – Demo Website

Pages: index, services, gallery, book, contact, my-bookings (customer panel), admin (owner panel, default PIN 1234).

Structure:
- css/style.css  – poora design (neumorphism + 3D)
- js/store.js    – data layer (abhi localStorage; asli backend ke liye yahi file badlein)
- js/layout.js   – header/footer/theme/menu (sab pages mein shared)
- js/<page>.js   – har page ka apna logic

Chalane ke liye: index.html browser mein kholein (ya kisi bhi static hosting par upload karein).
Note: data abhi sirf usi browser mein save hota hai. Alag customers aur owner ke liye real backend + database chahiye.
